//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DbgViewPlugin.rc
//
#define IDD_DBGVIEW_DIALOG              101
#define IDR_MAIN_MENU                   102
#define IDD_MESSAGE_DIALOG              103
#define IDC_DEBUGLISTVIEW               1001
#define IDC_MESSAGE                     1002
#define IDC_OPTIONS                     1003
#define IDC_AUTOSCROLL                  1004
#define IDC_ALWAYSONTOP                 1005
#define ID_EXCLUDEPROCESS_BYPID         40001
#define ID_EXCLUDEPROCESS_BYNAME        40002
#define ID_GOTOOWNINGPROCESS            40003
#define ID_PROPERTIES                   40004
#define ID_COPY                         40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
