//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DiskDrivesPlugin.rc
//
#define IDD_DISKDRIVE_OPTIONS           101
#define IDD_DISKDRIVE_DIALOG            102
#define IDC_GRAPH_LAYOUT                103
#define IDD_DISKDRIVE_PANEL             104
#define IDC_DISKDRIVE_LISTVIEW          1001
#define IDC_DISKDRIVE_NAME              1002
#define IDC_LAYOUT                      1003
#define IDC_STAT_BREAD                  1004
#define IDC_STAT_BWRITE                 1005
#define IDC_STAT_BTOTAL                 1006
#define IDC_STAT_ACTIVE                 1007
#define IDC_STAT_RESPONSETIME           1008
#define IDC_STAT_QUEUELENGTH            1009
#define IDC_STAT_CAPACITY               1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
