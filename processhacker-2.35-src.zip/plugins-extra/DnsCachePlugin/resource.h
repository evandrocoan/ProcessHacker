//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DnsCachePlugin.rc
//
#define IDD_DNSVIEW                     101
#define IDR_MAIN_MENU                   111
#define IDC_DNSLIST                     1021
#define IDC_DNS_REFRESH                 4355
#define IDC_DNS_CLEAR                   4356
#define ID_DNSENTRY_FLUSH               40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
