//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NvGpuPlugin.rc
//
#define IDD_GPU_PANEL                   100
#define IDD_GPU_DIALOG                  101
#define IDC_GRAPH_LAYOUT                102
#define IDC_TITLE                       103
#define IDC_GPUNAME                     104
#define IDC_PANEL_LAYOUT                105
#define IDC_GPU_L                       106
#define IDC_MEMORY_L                    107
#define IDC_SHARED_L                    108
#define IDC_SHARED_BUS                  109
#define IDC_BUS_L                       110
#define IDC_CLOCK_CORE                  111
#define IDC_CLOCK_MEMORY                112
#define IDC_FAN_PERCENT                 113
#define IDC_TEMP_VALUE                  114
#define IDC_CLOCK_SHADER                115
#define IDC_VOLTAGE                     117
#define IDC_DETAILS                     1001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
