//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PerfMonPlugin.rc
//
#define IDD_PERFMON_OPTIONS             112
#define IDD_PERFMON_DIALOG              113
#define IDC_GRAPH_LAYOUT                114
#define IDC_PERFCOUNTER_LISTVIEW        1023
#define IDC_ADD_BUTTON                  1024
#define IDC_REMOVE_BUTTON               1025
#define IDC_COUNTERNAME                 1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
