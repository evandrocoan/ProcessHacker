//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WaitChainPlugin.rc
//
#define IDD_WCT_DIALOG                  101
#define IDR_MAIN_MENU                   111
#define IDC_CUSTOM1                     1023
#define ID_DNSENTRY_FLUSH               40004
#define ID_MENU_GOTOTHREAD              40006
#define ID_MENU_PROPERTIES              40007
#define ID_MENU_COPY                    40008
#define ID_MENU_GOTOPROCESS             40009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40010
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
