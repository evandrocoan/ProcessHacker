//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ExtendedServices.rc
//
#define IDD_SVCLIST                     101
#define IDD_SRVLIST                     101
#define ID_SERVICE_RESTART              101
#define IDD_SRVRECOVERY                 102
#define ID_SERVICE_START                102
#define IDD_RESTARTCOMP                 103
#define ID_SERVICE_STOP                 103
#define IDD_SRVRECOVERY2                104
#define ID_SERVICE_GOTOSERVICE          104
#define IDD_SRVPROGRESS                 105
#define ID_SERVICE_CONTINUE             105
#define IDD_SRVOTHER                    106
#define ID_SERVICE_PAUSE                106
#define IDD_OPTIONS                     107
#define IDD_SRVTRIGGER                  108
#define IDD_VALUE                       109
#define IDC_SERVICES_LAYOUT             1001
#define IDC_MESSAGE                     1002
#define IDC_FIRSTFAILURE                1003
#define IDC_SECONDFAILURE               1004
#define IDC_SUBSEQUENTFAILURES          1005
#define IDC_RESETFAILCOUNT              1006
#define IDC_RESTARTSERVICEAFTER         1007
#define IDC_RESTARTSERVICEAFTER_LABEL   1008
#define IDC_RESTARTSERVICEAFTER_MINUTES 1009
#define IDC_ENABLEFORERRORSTOPS         1011
#define IDC_RESTARTCOMPUTEROPTIONS      1012
#define IDC_RUNPROGRAM                  1014
#define IDC_BROWSE                      1015
#define IDC_RESTARTCOMPAFTER            1016
#define IDC_ENABLERESTARTMESSAGE        1017
#define IDC_RESTARTMESSAGE              1018
#define IDC_RUNPROGRAM_GROUP            1019
#define IDC_RUNPROGRAM_LABEL            1020
#define IDC_RUNPROGRAM_INFO             1021
#define IDC_USEDEFAULTMESSAGE           1022
#define IDC_PROGRESS                    1023
#define IDC_PRESHUTDOWNTIMEOUT          1024
#define IDC_PRIVILEGES                  1025
#define IDC_TRIGGERS                    1026
#define IDC_TRIGGERS_LABEL              1027
#define IDC_ENABLESERVICESMENU          1028
#define IDC_TYPE                        1029
#define IDC_SUBTYPE                     1030
#define IDC_SUBTYPECUSTOM               1031
#define IDC_ACTION                      1032
#define IDC_LIST                        1033
#define IDC_NEW                         1034
#define IDC_EDIT                        1035
#define IDC_DELETE                      1037
#define IDC_VALUES                      1038
#define IDC_REMOVE                      1042
#define IDC_ADD                         1043

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
